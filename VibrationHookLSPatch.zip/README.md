# Vibration Hook for LSPatch

Purpose: detect `android.os.Vibrator.vibrate(...)` calls only inside FishingPlanet and send an explicit broadcast to Tasker.

Target package:
`com.FishingPlanetLLC.FishingPlanet`

Tasker intent action:
`com.ralifian.vibrationhook.VIBRATION_DETECTED`

Extras:
- `duration`
- `amplitude`
- `timestamp`

This project is configured for the classic Xposed API used by LSPatch non-root.
Build artifact: `app-release.apk`.

## Build
Use GitHub Actions -> Build LSPatch module -> Run workflow.
Then download the workflow artifact and extract `app-release.apk`.
