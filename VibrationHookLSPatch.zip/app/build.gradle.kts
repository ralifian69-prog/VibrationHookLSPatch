plugins {
    id("com.android.application")
}

android {
    namespace = "com.ralifian.vibrationhook"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.ralifian.vibrationhook"
        minSdk = 28
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            minifyEnabled = false
        }
    }
}

dependencies {
    compileOnly("de.robv.android.xposed:api:82")
}
