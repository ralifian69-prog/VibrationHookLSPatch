package com.ralifian.vibrationhook;

import android.content.Context;
import android.content.Intent;
import android.os.VibrationEffect;
import android.os.Vibrator;

import java.util.Arrays;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.AndroidAppHelper;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class HookEntry implements IXposedHookLoadPackage {
    private static final String TARGET = "com.FishingPlanetLLC.FishingPlanet";
    private static final String ACTION = "com.ralifian.vibrationhook.VIBRATION_DETECTED";

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET.equals(lpparam.packageName)) return;

        XposedBridge.log("VibrationHook: loaded in " + lpparam.packageName);

        // Hook every public vibrate overload we can safely resolve.
        tryHook("vibrate", new Object[]{long.class, XC_MethodHook.class});
        tryHook("vibrate", new Object[]{long[].class, int.class, XC_MethodHook.class});
        tryHook("vibrate", new Object[]{long[].class, int.class, android.media.AudioAttributes.class, XC_MethodHook.class});
        tryHook("vibrate", new Object[]{VibrationEffect.class, XC_MethodHook.class});
        tryHook("vibrate", new Object[]{VibrationEffect.class, android.media.AudioAttributes.class, XC_MethodHook.class});
    }

    private void tryHook(String method, Object[] signature) {
        try {
            Object[] args = Arrays.copyOf(signature, signature.length);
            args[args.length - 1] = new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    try {
                        long duration = extractDuration(param.args);
                        int amplitude = extractAmplitude(param.args);
                        broadcast(param.thisObject, duration, amplitude);
                    } catch (Throwable t) {
                        XposedBridge.log("VibrationHook: " + t);
                    }
                }
            };
            XposedHelpers.findAndHookMethod(Vibrator.class, method, args);
            XposedBridge.log("VibrationHook: hooked " + method);
        } catch (Throwable ignored) {
            // Signature may not exist on this Android build.
        }
    }

    private long extractDuration(Object[] args) {
        if (args == null) return 0;
        if (args.length > 0 && args[0] instanceof Long) return (Long) args[0];
        if (args.length > 0 && args[0] instanceof long[]) {
            long[] p = (long[]) args[0];
            long max = 0;
            for (long v : p) if (v > max) max = v;
            return max;
        }
        if (args.length > 0 && args[0] instanceof VibrationEffect) {
            return -1; // Effect; exact duration is intentionally not required.
        }
        return 0;
    }

    private int extractAmplitude(Object[] args) {
        if (args == null) return -1;
        if (args.length > 1 && args[1] instanceof Integer) return (Integer) args[1];
        return -1;
    }

    private void broadcast(Object vibratorObject, long duration, int amplitude) {
        if (!(vibratorObject instanceof Vibrator)) return;
        Context context = AndroidAppHelper.currentApplication();
        if (context == null) return;

        Intent intent = new Intent(ACTION);
        intent.setPackage("net.dinglisch.android.taskerm");
        intent.putExtra("duration", duration);
        intent.putExtra("amplitude", amplitude);
        intent.putExtra("timestamp", System.currentTimeMillis());
        context.sendBroadcast(intent);
    }
}
